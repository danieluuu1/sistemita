import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class MainFrame extends JFrame {

    private ArrayList<String> clientes = new ArrayList<>();
    private ArrayList<String> productos = new ArrayList<>();
    private DefaultTableModel productosModel;

    public MainFrame() {
        setTitle("Sistema de Facturación 1.1.0");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();

        JMenu archivoMenu = new JMenu("Archivo");
        JMenuItem salirMenuItem = new JMenuItem("Salir");
        salirMenuItem.addActionListener(e -> System.exit(0));
        archivoMenu.add(salirMenuItem);

        JMenu clientesMenu = new JMenu("Clientes");
        JMenuItem nuevoClienteMenuItem = new JMenuItem("Nuevo Cliente");
        nuevoClienteMenuItem.addActionListener(e -> openClientForm());
        clientesMenu.add(nuevoClienteMenuItem);

        JMenu productosMenu = new JMenu("Productos");
        JMenuItem nuevoProductoMenuItem = new JMenuItem("Nuevo Producto");
        nuevoProductoMenuItem.addActionListener(e -> openProductForm());
        productosMenu.add(nuevoProductoMenuItem);

        JMenu facturasMenu = new JMenu("Facturas");
        JMenuItem facturarMenuItem = new JMenuItem("Facturar");
        facturarMenuItem.addActionListener(e -> openInvoiceForm());
        facturasMenu.add(facturarMenuItem);

        menuBar.add(archivoMenu);
        menuBar.add(clientesMenu);
        menuBar.add(productosMenu);
        menuBar.add(facturasMenu);

        setJMenuBar(menuBar);
    }

    private void openClientForm() {
        ClientForm clientForm = new ClientForm(clientes);
        clientForm.setVisible(true);
    }

    private void openProductForm() {
        ProductForm productForm = new ProductForm(productos);
        productForm.setVisible(true);
    }

    private void openInvoiceForm() {
        InvoiceForm invoiceForm = new InvoiceForm(clientes, productos);
        invoiceForm.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    class ClientForm extends JFrame {

        private ArrayList<String> clientes;
        private JTextField nombreField;

        public ClientForm(ArrayList<String> clientes) {
            this.clientes = clientes;

            setTitle("Nuevo Cliente");
            setSize(400, 300);
            setLocationRelativeTo(null);

            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(4, 1));

            JLabel nombreLabel = new JLabel("Nombre del Cliente:");
            nombreField = new JTextField();

            JButton nuevoButton = new JButton("Nuevo");
            JButton guardarButton = new JButton("Guardar");
            JButton cancelarButton = new JButton("Cancelar");

            panel.add(nombreLabel);
            panel.add(nombreField);
            panel.add(nuevoButton);
            panel.add(guardarButton);
            panel.add(cancelarButton);

            add(panel);

            nuevoButton.addActionListener(e -> nuevoCliente());
            guardarButton.addActionListener(e -> guardarCliente());
            cancelarButton.addActionListener(e -> dispose());
        }

        private void nuevoCliente() {
            nombreField.setText("");
        }

        private void guardarCliente() {
            String nombre = nombreField.getText();
            if (!nombre.isEmpty()) {
                clientes.add(nombre);
                JOptionPane.showMessageDialog(this, "Cliente guardado: " + nombre);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "El nombre del cliente no puede estar vacío.");
            }
        }
    }

    class ProductForm extends JFrame {

        private ArrayList<String> productos;
        private JTextField nombreField;
        private JTextField precioField;

        public ProductForm(ArrayList<String> productos) {
            this.productos = productos;

            setTitle("Nuevo Producto");
            setSize(400, 300);
            setLocationRelativeTo(null);

            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(5, 1));

            JLabel nombreLabel = new JLabel("Nombre del Producto:");
            nombreField = new JTextField();
            JLabel precioLabel = new JLabel("Precio del Producto:");
            precioField = new JTextField();

            JButton nuevoButton = new JButton("Nuevo");
            JButton guardarButton = new JButton("Guardar");
            JButton cancelarButton = new JButton("Cancelar");

            panel.add(nombreLabel);
            panel.add(nombreField);
            panel.add(precioLabel);
            panel.add(precioField);
            panel.add(nuevoButton);
            panel.add(guardarButton);
            panel.add(cancelarButton);

            add(panel);

            nuevoButton.addActionListener(e -> nuevoProducto());
            guardarButton.addActionListener(e -> guardarProducto());
            cancelarButton.addActionListener(e -> dispose());
        }

        private void nuevoProducto() {
            nombreField.setText("");
            precioField.setText("");
        }

        private void guardarProducto() {
            String nombre = nombreField.getText();
            String precio = precioField.getText();
            if (!nombre.isEmpty() && !precio.isEmpty()) {
                productos.add(nombre + " - $" + precio);
                JOptionPane.showMessageDialog(this, "Producto guardado: " + nombre + " - $" + precio);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "El nombre y el precio del producto no pueden estar vacíos.");
            }
        }
    }

    class InvoiceForm extends JFrame {

        private ArrayList<String> clientes;
        private ArrayList<String> productos;
        private JComboBox<String> clientesComboBox;
        private DefaultTableModel productosModel;
        private JLabel subtotalLabel, ivaLabel, totalLabel;

        public InvoiceForm(ArrayList<String> clientes, ArrayList<String> productos) {
            this.clientes = clientes;
            this.productos = productos;

            setTitle("Facturar");
            setSize(600, 400);
            setLocationRelativeTo(null);

            JPanel panel = new JPanel(new BorderLayout());

            // Clientes
            JPanel clientesPanel = new JPanel();
            clientesPanel.add(new JLabel("Cliente:"));
            clientesComboBox = new JComboBox<>(clientes.toArray(new String[0]));
            clientesPanel.add(clientesComboBox);
            JButton seleccionarClienteButton = new JButton("Seleccionar Cliente");
            seleccionarClienteButton.addActionListener(e -> seleccionarCliente());
            clientesPanel.add(seleccionarClienteButton);

            panel.add(clientesPanel, BorderLayout.NORTH);

            // Productos
            String[] columnNames = {"Producto", "Cantidad", "Precio Unitario", "Precio Total"};
            productosModel = new DefaultTableModel(columnNames, 0);
            JTable productosTable = new JTable(productosModel);

            panel.add(new JScrollPane(productosTable), BorderLayout.CENTER);

            // Resumen
            JPanel resumenPanel = new JPanel(new GridLayout(3, 2));
            resumenPanel.add(new JLabel("Subtotal:"));
            subtotalLabel = new JLabel("0.00");
            resumenPanel.add(subtotalLabel);
            resumenPanel.add(new JLabel("IVA:"));
            ivaLabel = new JLabel("0.00");
            resumenPanel.add(ivaLabel);
            resumenPanel.add(new JLabel("Total:"));
            totalLabel = new JLabel("0.00");
            resumenPanel.add(totalLabel);

            panel.add(resumenPanel, BorderLayout.SOUTH);

            add(panel);

            // Agregar botones para agregar productos y calcular totales
            JButton agregarProductoButton = new JButton("Agregar Producto");
            agregarProductoButton.addActionListener(e -> agregarProducto());
            panel.add(agregarProductoButton, BorderLayout.EAST);

            JButton calcularTotalesButton = new JButton("Calcular Totales");
            calcularTotalesButton.addActionListener(e -> calcularTotales());
            panel.add(calcularTotalesButton, BorderLayout.WEST);
        }

        private void seleccionarCliente() {
            String clienteSeleccionado = (String) clientesComboBox.getSelectedItem();
            JOptionPane.showMessageDialog(this, "Cliente seleccionado: " + clienteSeleccionado);
        }

        private void agregarProducto() {
            String productoSeleccionado = (String) JOptionPane.showInputDialog(
                    this,
                    "Seleccionar Producto",
                    "Agregar Producto",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    productos.toArray(),
                    null);

            if (productoSeleccionado != null && !productoSeleccionado.isEmpty()) {
                String[] parts = productoSeleccionado.split(" - \\$");
                String nombreProducto = parts[0];
                double precioUnitario = Double.parseDouble(parts[1]);
                int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad:"));
                double precioTotal = precioUnitario * cantidad;

                productosModel.addRow(new Object[]{nombreProducto, cantidad, precioUnitario, precioTotal});
            }
        }

        private void calcularTotales() {
            double subtotal = 0.0;
            for (int i = 0; i < productosModel.getRowCount(); i++) {
                subtotal += (Double) productosModel.getValueAt(i, 3);
            }
            double iva = subtotal * 0.12;
            double total = subtotal + iva;

            subtotalLabel.setText(String.format("%.2f", subtotal));
            ivaLabel.setText(String.format("%.2f", iva));
            totalLabel.setText(String.format("%.2f", total));
        }
    }
}

